import java.util.Scanner;
/**Child class of the Item class
 * 
 * @author Noshin
 *
 */
public class Device extends Item {
	private int brainCapValue;
	public int getBrainCapValue() {
		return brainCapValue;
	}

	private String deviName;           //field for the name, x position and y position of device
	private int devPosx;
	private int devPosy;
	
	
/**Constructor for the Device that sets the
 * 
 * @param dvn name of device
 * @param bcv   it's brain capacity value
 * @param x  x position of device on map
 * @param y  y position of device on map
 * @param map  map to be placed on
 */
	public Device(String dvn, int bcv, int x, int y, Map map) {
		super(dvn,bcv);
		deviName = dvn;
		brainCapValue = bcv;
		devPosx = x;
		devPosy = y;
		map.itemPos(x,y);    //places the device as an item on the map with the x and y parameters
	}
/**Method that is activated when the player's position lines up with the device's position
 * It asks you if you want to collect it or not, once collected, your brain capacity increases
 * by the device's brain cap value
 * @param p1 the player
 * @param luggage  where the device will be added to
 * @param d device object
 * @param map display the map
 */
	public void useDevice(Player p1, Inventory luggage, Device d, Map map) {
		Scanner sc = new Scanner(System.in);
		if(d.getDevPosx() == map.getxPos() && d.getDevPosy() == map.getyPos() && map.itemTileStatus(d.getDevPosx(), d.getDevPosy()) == true) {
			System.out.println("You have landed on a " + deviName+ ". Type c to collect it and add it to your luggage." + "\n" 
					+ " Otherwise type w a s or d to keep moving.");
			String collected = sc.nextLine();
			if (collected.equals("c")) {
				luggage.addIt(d,p1);
				p1.setBrainCap(p1.getBrainCap() + brainCapValue);
				p1.PlayerUnchanged(p1);
				System.out.println("Your Brain Capacity has increased by: " + brainCapValue);
				map.encounterdItemPos(d.getDevPosx(),d.getDevPosy());
				System.out.print(p1);
				map.displayMap();
			}
			else if(collected.equals("w") || collected.equals("a") || collected.equals("s") || collected.equals("d")) {
				p1.setToPositiveValues(p1);
				p1.PlayerUnchanged(p1);
				map.displayMap();
			
			}
		}
		
	}

	public int getDevPosx() {
		return devPosx;
	}

	public void setDevPosx(int devPosx) {
		this.devPosx = devPosx;
	}

	public int getDevPosy() {
		return devPosy;
	}

	public void setDevPosy(int devPosy) {
		this.devPosy = devPosy;
	}
	
	public String toString() {
		return deviName + ": \nBrain Capacity Value of" + brainCapValue;
	}


}