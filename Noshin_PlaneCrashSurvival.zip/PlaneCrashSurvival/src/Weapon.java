import java.util.*;
/**Child class named weapon of item class
 * 
 */
public class Weapon extends Item {
	private String weaponName; //local variable for Weapon class
	int weaPosx;   
	int weaPosy;

	
/**Constructor that intializes weapon's name and position on map
 * 
 * @param wn name of weapon
 * @param x x pos
 * @param y y pos
 * @param map map
 */
	public  Weapon (String wn, int x, int y,Map map) {
		super(wn,5);
		weaponName= wn;
		weaPosx = x;
		weaPosy = y;
		map.itemPos(x, y);

	}


	public int getWeaPosx() {
		return weaPosx;
	}


	public void setWeaPosx(int weaPosx) {
		this.weaPosx = weaPosx;
	}


	public int getWeaPosy() {
		return weaPosy;
	}


	public void setWeaPosy(int weaPosy) {
		this.weaPosy = weaPosy;
	}

/**When player and weapon's position overlap, player is asked if they want to collect the weapon
 * if so weapon is added to the luggage
 * 
 * @param p1 player
 * @param luggage arraylist
 * @param w weapon object
 * @param map map
 */
	public void useWeapon(Player p1, Inventory luggage, Weapon w, Map map ) {
		Scanner sc = new Scanner(System.in);
		if(w.getWeaPosx() == map.getxPos() && w.getWeaPosy() == map.getyPos() && map.itemTileStatus(w.getWeaPosx(),w.getWeaPosy())==true) {

			System.out.println("You have landed on a " + weaponName+ " (Great for attacking!). Type c to collect it and add it to your luggage." + "\n" 
					+ " Otherwise type w a s d to keep moving.");
			String collected = sc.nextLine();
			if(collected.equals("c")) {
				p1.setAttack(p1.getAttack() + 5);
				p1.PlayerUnchanged(p1);
				System.out.println(p1);
				System.out.println("Your attack has increased by: 5");
				luggage.addIt(w,p1);
				map.displayMap();
				map.encounterdItemPos(w.getWeaPosx(), w.getWeaPosy());
			}
			else {
				map.movePlayer(collected);
				map.displayMap();
				p1.PlayerUnchanged(p1);
			}
		}
	

	}
	/** How the object appears in the arrayList
	 * 
	 */
	public String toString() {
		return weaponName + ":  \nAttack Value of 5";
	}
}
