import java.io.Serializable;
public class Player implements Serializable{
	/*
	 * Player class that initializes player's health, brain capacity defense level,
	 * attack level, and their game status (dead or alive)
	 */
	private String survivorName;
	private int HP;
	private int brainCap;
	private int attack; 
	private int defense;
	int playerX;
	int playerY;
	
/**
 * Constructor that initializes player stats and position on map
 * @param n name of player
 * @param map map
 */
	public  Player (String n, Map map) {
		survivorName = n;
		HP = 20;
		brainCap = 10;
		attack = 10;
		defense = 10;
		playerX = map.getxPos();
		playerY = map.getyPos();
	

	}

	public String getSurvivorName() {
		return survivorName;
	}

	public void setSurvivorName(String survivorName) {
		this.survivorName = survivorName;
	}

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getBrainCap() {
		return brainCap;
	}

	public void setBrainCap(int brainCap) {
		this.brainCap = brainCap;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int d) {
		this.attack = d;
	}

	public int getDefense() {
		return defense;
	}

	public void setDefense( int defense) {
		this.defense = defense;
	}



	public String toString() {
		return "STATS" + "\n" + "~~~~~~~~~~~~~~~~~~~~" + "\n" + "Player name: " + survivorName + "\n" + "HP: " + HP + "\n" + "Brain Capacity: " 
				+ brainCap + "\n" + "Attack: " + attack + "\n" + "Defense: " + defense;
				
	}
/**Keeps player's stats as they are without changing them
 * 
 * @param p1 player 
 */
	public void PlayerUnchanged(Player p1) {
		p1.setHP(p1.getHP());
		p1.setDefense(p1.getDefense());
		p1.setAttack(p1.getAttack());
		p1.setBrainCap(p1.getBrainCap());
	}
/**Make sure values are never negative
 * 
 * @param p player
 */
	public void setToPositiveValues(Player p) {
		if (p.getAttack() < 0 ) {
			p.setAttack(0);
		}
		else if (p.getBrainCap() < 0) {
			p.setDefense(0);
		}
		else if (p.getBrainCap() < 0) {
			p.setBrainCap(0);
		}
		else if (p.getHP()< 0) {
			p.setHP(0);
		}
	}
/**Whenever in the game, the player loses HP,
 *then game over, the player has died
 * @param p player
 */
	public void OutOfHP(Player p) {
		if (p.getHP() <=0) {
			System.out.println("You've run out of HP. You are dead.");
			System.exit(0); //function that terminates application

		}
	}

}