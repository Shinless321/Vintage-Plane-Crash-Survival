import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class PlaneCrashSurvival {
/** Main method that asks for name of user and initializes player object
 * 
 * @param args 
 * @throws IOException  player is saved when game exits before it ends
 */
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.print("Welcome to Plane Crash Survival! \n Please enter your"
				 + " name: ");
		String pName = sc.nextLine();
		Map map1  = new Map();
		Player p1 = new Player (pName,map1);
		
		Inventory luggage1 = new Inventory ();
		System.out.println(p1);
		System.out.println("Are you ready to play? Type y for Yes or n for No.");
		String ans = sc.nextLine();
		if( ans.equals("y")) {
			runGame(pName,p1,luggage1,map1);
		}
		else if (ans.equals("n")) {
			System.out.println("See you next time!");
		}
		else if (!(ans.equals("y")) && !(ans.equals("n"))) {
			while(!(ans.equals("y")) && !(ans.equals("n"))) {
			System.out.println("Key not recognized. You may type y for yes or n for no.");
			ans = sc.nextLine();
		}if(ans.equals("y")) {
			runGame(pName,p1,luggage1,map1);
		}
		}
		else if (ans.equals("n")) {
			System.out.println("See you next time!");
			
		}
		System.out.println("Thanks for playing. Select load game next time to resume your progress.");
		System.exit(1);
		
		FileOutputStream fout = new FileOutputStream("save.ser");
		  ObjectOutputStream oos = new ObjectOutputStream(fout);
		  oos.writeObject(p1);
		  oos.close();
	}

/**Run game method, where objects are created and methods are called
 * 
 * @param pName player name
 * @param p1 player stats
 * @param luggage1 inventory object
 * @param map1 
 */

	public static void runGame(String pName, Player p1, Inventory luggage1, Map map1) {
		Scanner sc = new Scanner(System.in);
		System.out.println(pName + ", you have been lucky enough to survive the crash of Boeing+023 near a foreign island.\n It is crucial that you reach the safe house to seek help and recover before you die off.");
		System.out.println("Try to reach the safe house without losing too much HP or Brain Capacity.");
		System.out.println("Watch out for enemies. There are 2 Sharks that will kill you instantly. \n Your best hope is to find items that will benefit you towards your survival.");
		System.out.println("Good Luck.");
		
		map1.displayMap();
		System.out.println("Use the keys w, a, s ,d to move through the map. Watch out for enemies along the way. Press n anytime to exit and save your game.");
		String move;
		move = sc.nextLine();
		map1.movePlayer(move);
		map1.displayMap();
		Weapon w1 = new Weapon("katana",(int)(Math.random() * 6)   +0 ,(int)(Math.random() * 5)   +0,map1);
		Food f1 = new Food("Coconut",11,(int)(Math.random() * 6)   +0 ,(int)(Math.random() * 5) + +0,map1);
		LifeJacket lj1 = new LifeJacket("life jacket",15,(int)(Math.random() * 5)   +0 ,(int)(Math.random() * 5)  +0,map1);
		Device d1 = new Device("Compass",11,(int)(Math.random() * 6)   +0 ,(int)(Math.random() * 3)  +0,map1);
		PoisonousSnake sn1 = new PoisonousSnake ("cobra",21,15,11,21,(int)(Math.random() * 4)  +0 ,(int)(Math.random() * 4)  +0 ,map1);
		Piranha pi2 =new Piranha("red-bellied piranha",14,11,0 ,(int)(Math.random() * 5)  +0,map1);
		Piranha pi3 =new Piranha("sharp-snouted piranha",21,21,(int)(Math.random() * 5)   +0 ,(int)(Math.random() * 4)  +0,map1);
		Food f2 = new Food("Pineapple",11,(int)(Math.random() * 6)   +0,(int)(Math.random() * 3)  +0,map1);
		PoisonousSnake sn2 = new PoisonousSnake ("Viper",11,11,11,11,(int)(Math.random() * 6)  +0 ,0 ,map1);
		PoisonousSnake sn3 = new PoisonousSnake ("Indian Boa",21,21,11,21,(int)(Math.random() * 6)  +0 ,(int)(Math.random() * 4)  +0 ,map1);
		Weapon w2 = new Weapon("bow and Arrow",(int)(Math.random() * 6)   +0 ,(int)(Math.random() * 4)  +0,map1);
	    Shark shk1 = new Shark ("Hammer-Head Shark", (int)(Math.random() * 6)   +0,(int)(Math.random() * 5) +0,map1);
	    Shark shk2 = new Shark("Great-White Shark",(int)(Math.random() * 6)   +0,(int)(Math.random() * 5)  +0,map1);
		LifeJacket lj2 = new LifeJacket("Oxygen Mask",24,(int)(Math.random() * 5)   +0 ,(int)(Math.random() *5)  +0,map1);
		SafeHouse sh1 = new SafeHouse(5,4,map1);
		Potion potion1 = new Potion("power potion",(int)(Math.random() * 6) +0,(int)(Math.random() * 4) +  0 ,map1);
		while (!(move.equals("n"))) {
			p1.setToPositiveValues(p1);
			move =sc.nextLine();
			map1.movePlayer(move);
			p1.PlayerUnchanged(p1);
			map1.displayMap();
			w1.useWeapon(p1, luggage1,w1,map1);
			f1.useFood(p1,luggage1,f1,map1);
			lj1.useLifeJacket(p1,luggage1,lj1,map1);
			d1.useDevice(p1,luggage1,d1,map1);
			sn1.sAttacked(p1,sn1,map1);
			pi2.pAttacked(p1, pi2, map1);
			pi3.pAttacked(p1, pi3, map1);
			f2.useFood(p1, luggage1, f2, map1);
			sn2.sAttacked(p1,sn2,map1);
			sn3.sAttacked(p1, sn3, map1);
			w2.useWeapon(p1, luggage1, w2, map1);
			shk1.sharkAttack(p1,shk1,map1);
			shk2.sharkAttack(p1, shk2, map1);
			sn3.sAttacked(p1, sn3, map1);
			lj2.useLifeJacket(p1, luggage1, lj2, map1);
			sh1.Safety(p1,sh1,map1);
			potion1.drinkPotion(p1, potion1, map1);
		} 
	}
		

		 

	}
	
	
	  



