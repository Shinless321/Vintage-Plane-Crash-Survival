import java.util.Scanner;
/**Child class of item class
 * 
 * @author Noshin
 *
 */
public class Potion extends Item{
	private String potionName;
	int potiPosx;
	int potiPosy;

	
/**Constructor that passes potion name to parent class and initializes x and y positions on map when called
 * 
 * @param potn potion name
 * @param x x pos
 * @param y y pos
 * @param map map
 */
	public  Potion (String potn, int x, int y,Map map) {
		super(potn,10);
		potionName= potn;
		potiPosx = x;
		potiPosy = y;
		map.itemPos(x, y);

	}


	
/** When player lands on potion positio, they are asked to drink it if they want 
 * 
 * @param p1 player
 * @param pn potion object
 * @param map map
 */
	public void drinkPotion(Player p1, Potion pn, Map map ) {
		Scanner sc = new Scanner(System.in);
		if(pn.getPotiPosx() == map.getxPos() && pn.getPotiPosy() == map.getyPos() && map.itemTileStatus(pn.getPotiPosx(),pn.getPotiPosy())==true) {

			System.out.println("WOW! You've found a rare  " + potionName+ ". This powers your health and stamina all at once. \nI would assume you would like to drink it? \n" 
					+ " Type d to drink the "+potionName +" Otherwise type w a s d to keep moving.");
			String collected = sc.nextLine();
			if(collected.equals("d")) {
				p1.setAttack(p1.getAttack() + 10);
				p1.setBrainCap(p1.getBrainCap() + 10);
				p1.setHP(p1.getHP()+10);
				p1.setDefense(p1.getDefense()+10);
				System.out.println(p1);
				System.out.println("Your attack, brain capacity, defense and HP has increased by: 10");
				System.out.print(p1);
				map.displayMap();
				map.encounterdItemPos(pn.getPotiPosx(), pn.getPotiPosy());
			}
			else {
				map.movePlayer(collected);
				map.displayMap();
				p1.PlayerUnchanged(p1);
			}
		}
	

	}




	public String getPotionName() {
		return potionName;
	}




	public void setPotionName(String potionName) {
		this.potionName = potionName;
	}




	public int getPotiPosx() {
		return potiPosx;
	}




	public void setPotiPosx(int potiPosx) {
		this.potiPosx = potiPosx;
	}




	public int getPotiPosy() {
		return potiPosy;
	}




	public void setPotiPosy(int potiPosy) {
		this.potiPosy = potiPosy;
	}



}

