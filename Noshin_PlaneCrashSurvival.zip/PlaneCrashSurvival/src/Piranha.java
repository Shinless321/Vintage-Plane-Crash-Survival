/** Child class names piranha of enemy class
 * 
 * @author Noshin
 *
 */
public class Piranha extends Enemy {
	private int piranXpos;
	private int piranYpos;

	public int getPiranXpos() {
		return piranXpos;
	}

	public void setPiranXpos(int piranXpos) {
		this.piranXpos = piranXpos;
	}

	public int getPiranYpos() {
		return piranYpos;
	}

	public void setPiranYpos(int piranYpos) {
		this.piranYpos = piranYpos;
	}

	private int pBrainDamage=15;

/**Constructor that passes piranha name, attack level and HP level into parent class
 * 
 * @param piranName initializes a name
 * @param piranAttack initializes attack
 * @param piranHP initializes HP
 * @param x sets x pos
 * @param y sets y pos
 * @param map places values on map
 */
	public Piranha(String piranName, int piranAttack, int piranHP, int x, int y, Map map) {
		super(piranName,piranAttack,piranHP);
		pBrainDamage = 15;
		piranXpos= x;
		piranYpos = y;
		map.enemyPos(x, y);
	}
/** When player and piranha's position align, attack method is called from enemy class
 * if player has lost attack, player will lose additional HP and brain capacity values
 * @param p1 player
 * @param pi piranha object
 * @param map map
 */
	public void pAttacked( Player p1, Piranha pi, Map map) {
		if(pi.getPiranXpos() == map.getxPos() && pi.getPiranYpos() == map.getyPos() && map.enemyTileStatus(pi.getPiranXpos(),pi.getPiranYpos()) ==true) {
			pi.attack(p1, pi, map);
			map.encounterdEnemyPos(pi.getPiranXpos(), pi.getPiranYpos());
			if (loseAttack = true) {
				p1.setBrainCap(p1.getBrainCap() - pBrainDamage/2);
				p1.setHP(p1.getHP() - pBrainDamage/4);
				p1.setToPositiveValues(p1);
				p1.PlayerUnchanged(p1);
			}
			else {
				p1.PlayerUnchanged(p1);

			}

		}

	}

}
