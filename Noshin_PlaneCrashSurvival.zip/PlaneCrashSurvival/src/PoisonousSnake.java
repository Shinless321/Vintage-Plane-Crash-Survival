/** Child class names poisonoussnake of enemy class
 * 
 * @author Noshin
 *
 */
public class PoisonousSnake extends Enemy {
	private int snakeDefense;
	int snakeAttack;
	private int snakeXpos;
	private int snakeYpos;

	public int getSnakeXpos() {
		return snakeXpos;
	}
	public void setSnakeXpos(int snakeXpos) {
		this.snakeXpos = snakeXpos;
	}
	public int getSnakeYpos() {
		return snakeYpos;
	}
	public void setSnakeYpos(int snakeYpos) {
		this.snakeYpos = snakeYpos;
	}

/**Constructor that passes poisonous snake name, attack level and HP level into parent class
 * 
 */
	public PoisonousSnake(String snakeName,int snakeAttack,int sA,int snakeHP,int sD, int x, int y, Map map) {
		super(snakeName,snakeAttack,snakeHP);	
		snakeAttack  = sA;
		snakeDefense = sD;
		snakeXpos = x;
		snakeYpos = y;
		map.enemyPos(x, y);

	}
/**Method when snake and player's position overlap
 * attack method is called from enemy and player loses addtional defense and attack values
 * @param p1 player
 * @param s1 snake
 * @param map map
 */
	public void sAttacked( Player p1, PoisonousSnake s1, Map map) {
		if(s1.getSnakeXpos() == map.getxPos() && s1.getSnakeYpos() == map.getyPos() && map.enemyTileStatus(s1.getSnakeXpos(),s1.getSnakeYpos()) ==true) {
			s1.attack(p1,s1,map);
			map.encounterdEnemyPos(s1.getSnakeXpos(),s1.getSnakeYpos() );
			if (loseAttack = true) {
				p1.setAttack((p1.getAttack() - snakeAttack/2));
				p1.setDefense( (p1.getDefense()-snakeDefense/2));
				p1.setToPositiveValues(p1);
				p1.PlayerUnchanged(p1);
			}
			else {
				p1.PlayerUnchanged(p1);

			}
		}

	}
}
