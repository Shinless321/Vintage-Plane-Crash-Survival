import java.util.ArrayList;
import java.util.*;

/** Method that declares the class Inventory ---> ArrayList
 * 
 * @author Noshin
 *
 */
public class Inventory {
	ArrayList<Item> luggage = new ArrayList<Item>();
	private int currentStorage;
	boolean tooFull;
/**Constructor initializing an arrayList called luggage when it's called and 
 * initializes it's storage to 0
 */

	public Inventory() {
		currentStorage = 0;
		ArrayList<Item> luggage = new ArrayList<Item>();
	}

  /** Method that adds item to the arraylist if luggage capacity allows otherwise 
   * asks user if they want to remove an item to make space for a new one
   * 
   * @param a item object
   * @param p1 player
   */
	public void addIt(Item a,Player p1) {
		if(currentStorage<3){
			luggage.add(a);
			currentStorage = currentStorage +1;
		}
		else {
			System.out.println("Your luggage is too full. You've reached the capacity of 3 items. \n Would you like to remove an item to make space \n for your new one?");
			System.out.println("Type r to remove otherwise continue moving(w,a,s,d).");
			Scanner sc = new Scanner(System.in);
			String rem = sc.nextLine();
			if (rem.equals("r")) {
				for (Item x: luggage) {
					System.out.println("--------");
					System.out.println(x);

				}
				System.out.println("Of the following items, which would you like to remove? (Type the number in order.. eg. 1st item is 1)");
				int num = sc.nextInt();
				findItem(num,p1);
				luggage.add(a);


			}
		}
	}

/** Method that removes item
 * 
 * @param b item object
 */
	public void remove (Item b) {
		luggage.remove(b);
		currentStorage = currentStorage -1;
	}
	/** Method that retrieves an item from an arraylist and removes it
	 * depending on which class the item belongs to, player's health value will decrease
	 * 
	 * @param x index of object entered by user
	 * @param p1 player
	 */
	public void findItem(int x,Player p1) {
		Item y = luggage.get(x-1);
		remove(y);
		if (y.getClass() ==Food.class) {
			p1.setHP(p1.getHP() - y.getObjectPower());
			System.out.println(y + " has been removed from your luggage. Please proceed.");
		}
		else if(y.getClass() == LifeJacket.class) {
			p1.setDefense(p1.getDefense() - y.getObjectPower());
			System.out.println(y + " has been removed from your luggage. Please proceed.");
		}
		else if (y.getClass() == Weapon.class) {
			p1.setAttack(p1.getAttack() - y.getObjectPower());
			System.out.println(y + " has been removed from your luggage. Please proceed.");
		}
		else if (y.getClass() == Device.class) {
			p1.setBrainCap(p1.getBrainCap() - y.getObjectPower());
			System.out.println(y + " has been removed from your luggage. Please proceed.");
		}

	}




}
