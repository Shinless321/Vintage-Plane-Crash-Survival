/**Parent class that declares the name, health, attack level of
 * enemies as well as whether the player has won or lost the battle
 * with an enemy
 * @author Noshin
 *
 */
import java.util.*;
public class Enemy {   
	private String enemName;
	private int enemHP;
	private int enemAttack;
	boolean loseAttack;

	Scanner sc = new Scanner (System.in);

	public int getEnemAttack() {
		return enemAttack;
	}

	public void setEnemAttack(int enemAttack) {
		this.enemAttack = enemAttack;
	}
	/**Constructor that assigns values for an enemy every time an enemy
	 * object is created
	 * @param eN the enemy name
	 * @param eHP the health of the enemy
	 * @param eA the attack 
	 */
	public Enemy (String eN,int eHP, int eA) {
		enemName = eN;
		enemHP = eHP;
		enemAttack = eA;
	}

	public String getEnemName() {
		return enemName;
	}

	public void setEnemName(String enemName) {
		this.enemName = enemName;
	}

	public int getEnemHP() {
		return enemHP;
	}

	public void setEnemHP(int enemHP) {
		this.enemHP = enemHP;
	}
	
	/**When the player's x and y position and enemy's position
	 * line up,  it compares who has the higher attack
	 * if the player has more, they can proceed,
	 * otherwise the player must enter a random number and compare it
	 * to a randomly generated number. If they guess correct, they are unharmed by the enemy.
	 * If they guess wrong, they lose a portion of HP and ATTACK of the enemy
	 * @param p1 player
	 * @param a enemy object
	 * @param map  to be displayed, find players position
	 */
	public void attack(Player p1, Enemy a, Map map) {
		
		if ( p1.getAttack() > a.getEnemAttack() && map.enemyTileStatus(map.getxPos(),map.getyPos())==true) {
			System.out.println("Looks like you've encountered a " + a.getEnemName() + "!");
			p1.OutOfHP(p1);
			loseAttack = false;
			System.out.println("Luckily, you were able to defend yourself against " + a.getEnemName() + "\n as you were blessed with plenty of attacking power!");
		}
		else if (p1.getAttack() < a.getEnemAttack() ) {

			int num=0;
			
			
			System.out.println("Looks like you've encountered a " + a.getEnemName() + "!");
			p1.OutOfHP(p1);
			loseAttack =false;

			System.out.println("Unfortunately, you're not in the best position to defend yourself." + "\n" +
					"But you can still fight with luck.... Guess a number between 1 and 2. If your number matches, you're safe.");
			
			do { 
				try {                                     //if a user tries to enter something other than an integer, it will catch it
					System.out.println("Enter:");
					
					  num =  sc.nextInt();
				}catch(Exception e) {
				}
				} while (p1.getAttack() < a.getEnemAttack() && p1.getAttack() > a.getEnemAttack() && map.enemyTileStatus(map.getxPos(),map.getyPos())==true );
					int eneNum = (int)(Math.random() * 3) + 0;


					if (num == eneNum) {
						loseAttack = false;
						System.out.println("You guessed right! You walked away with no damage at all.");
						p1.PlayerUnchanged(p1);   //keep the player's values (hp, defense etc.) as it it
						System.out.print(p1);    //print the player's stats
						map.displayMap();
					}
					else  if (num!= eneNum) {
						loseAttack = true;

						p1.setHP(p1.getHP() - (a.getEnemHP()/3));
						p1.setAttack(p1.getAttack() - (p1.getAttack()/2));
						p1.setToPositiveValues(p1);
						p1.PlayerUnchanged(p1);

						System.out.println("You were unable to defend yourself against the " + a.getEnemName() + "! " + p1.getSurvivorName()
						+ " has been hurt." + "\n" + "Current HP:" + p1.getHP());
						System.out.println("Current Brain Capacity: " + p1.getBrainCap());
						System.out.println("Current Defense: " + p1.getDefense());
						System.out.println("Current Attack: " + p1.getAttack());
						map.displayMap();
						p1.OutOfHP(p1);

					}
			
			



		

	}
}
}





		