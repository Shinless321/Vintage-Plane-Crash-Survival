/** Position class for every tile
 * 
 * @author Noshin
 *
 */
public class Position {

	private String typeDisplay;
	private boolean playerOnTile; //if a player is on tile or not 
	private boolean SafeHouse; //if a safe house is on tile or not
	private boolean enemyTile; //if an enemy is on tile or not
	private boolean itemTile;  // if an item is on tile or not
/**Constructor that initializes the status of every tile and display
 * 
 * @param dsply display
 */
	public Position (String dsply) {
		typeDisplay = dsply;
		playerOnTile = false;
		SafeHouse = false;
		enemyTile = false;
		itemTile = false;

	}




	public String getTypeDisplay() {
		return typeDisplay;
	}




	public void setTypeDisplay(String typeDisplay) {
		this.typeDisplay = typeDisplay;
	}




	public boolean isPlayerOnTile() {
		return playerOnTile;
	}




	public void setPlayerOnTile(boolean playerOnTile) {
		this.playerOnTile = playerOnTile;
	}




	public boolean isSafeHouse() {
		return SafeHouse;
	}




	public void setSafeHouse(boolean safeHouse) {
		SafeHouse = safeHouse;
	}




	public boolean isEnemyTile() {
		return enemyTile;
	}




	public void setEnemyTile(boolean enemyTile) {
		this.enemyTile = enemyTile;
	}



/**
 * 
 * @return
 */
	public boolean isItemTile() {
		return itemTile;
	}




	public void setItemTile(boolean itemTile) {
		this.itemTile = itemTile;
	}




	public String toString() {
		if (isSafeHouse() && playerOnTile) {
			return "*";
		}

		if (isEnemyTile() && playerOnTile) {
			return "!";

		}
		if (isItemTile() && playerOnTile) {
			return "$";
		}
		if (playerOnTile) {
			return "P";
		}

		return "O";
	}
}
