import java.util.*;

/**Child Class Food of Item class
 * 
 * @author Noshin
 *
 */
public class Food extends Item {
	private String foodName;
	private int hpValue;
	int foodPosx;
	int foodPosy;
	
/**Constructor that initializes the 
 * 
 * @param fn name of food
 * @param hpv HP value of the food
 * @param x xposition of the food
 * @param y yposition of the food
 * @param map  place the food object on the map
 */
	public Food ( String fn, int hpv, int x, int y, Map map) {
		super(fn,hpv);
		foodName = fn;
		hpValue = hpv;
		foodPosx = x;
		foodPosy = y;
		map.itemPos(x, y);
	}
	
	/**Method for when the player and food positions align, 
	 * the player is asked to collect it and add it to the luggage
	 * @param p1  player 
	 * @param luggage  where the food will be stored to
	 * @param f   the food object
	 * @param map  where the food is placed
	 */
	public void useFood(Player p1, Inventory luggage, Food f, Map map) {
		Scanner sc = new Scanner(System.in);
		if(f.getFoodPosx() == map.getxPos() && f.getFoodPosy() == map.getyPos() && map.itemTileStatus(f.getFoodPosx(),f.getFoodPosy()) == true) {

			System.out.println("You have landed on a " + foodName+ " (Great for refueling!). Type c to collect it and add it to your luggage." + "\n" 
					+ " Otherwise type w a s d  to keep moving.");

			String collected = sc.nextLine();
			if (collected.equals("c")) {
				luggage.addIt(f,p1);
				p1.setHP(p1.getHP() + hpValue);
				p1.PlayerUnchanged(p1);
				System.out.println("Your HP has increased by: " + hpValue);
				map.encounterdItemPos(f.getFoodPosx(), f.getFoodPosy());
				System.out.print(p1);
				map.displayMap();	
			}
			else if(collected.equals("w") || collected.equals("a") || collected.equals("s") || collected.equals("d")) {
				map.movePlayer(collected);
				map.displayMap();
				p1.PlayerUnchanged(p1);
			}
		}
		
	}
	public int getFoodPosx() {
		return foodPosx;
	}
	public void setFoodPosx(int foodPosx) {
		this.foodPosx = foodPosx;
	}
	public int getFoodPosy() {
		return foodPosy;
	}
	public void setFoodPosy(int foodPosy) {
		this.foodPosy = foodPosy;
	}
	
	public String toString() {
		return foodName + ": \n HP Value:" + hpValue;
	}
	public int getHpValue() {
		return hpValue;
	}
}

