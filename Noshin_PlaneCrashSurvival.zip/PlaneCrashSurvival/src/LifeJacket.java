import java.util.Scanner;
/** Child class lifejacket of item class
 * 
 * @author Noshin
 *
 */
public class LifeJacket extends Item {
	private int defValue;
	
	private String ljName;
	int lifejkPosx;
	int lifejkPosy;

	/** Constructor that passes the name and defense value into parent class
	 * and places object on map
	 * 
	 * @param ljn lifejacket name
	 * @param dv  defense value
	 * @param x   x position
	 * @param y   y position
	 * @param map where object will be placed
	 */
	public LifeJacket (String ljn, int dv,int x, int y,Map map) {
		super(ljn,dv);
		ljName = ljn;
		defValue = dv;
		lifejkPosx = x;
		lifejkPosy = y;
		map.itemPos(x, y);

	}


	public int getLifejkPosx() {
		return lifejkPosx;
	}
	public void setLifejkPosx(int lifejkPosx) {
		this.lifejkPosx = lifejkPosx;
	}
	public int getLifejkPosy() {
		return lifejkPosy;
	}
	public void setLifejkPosy(int lifejkPosy) {
		this.lifejkPosy = lifejkPosy;
	}

	public int getDefValue() {
		return defValue;
	}
	/** Method that is called when the player and lifejacket position are aligned
	 * Users asked to collect item and store it in luggage
	 * 
	 * @param p1 player
	 * @param luggage arraylist
	 * @param lj lifejacket object
	 * @param map map
	 */
	public void useLifeJacket(Player p1, Inventory luggage, LifeJacket lj, Map map) {
		Scanner sc = new Scanner(System.in);
		if(lj.getLifejkPosx() == map.getxPos() && lj.getLifejkPosy() == map.getyPos() && map.itemTileStatus(lj.getLifejkPosx(),lj.getLifejkPosy())==true) {

			System.out.println("You have landed on a " + ljName+ ". Type c to collect it and add it to your luggage." + "\n" 
					+ " Otherwise type w a s or d to keep moving.");
			String collected = sc.nextLine();
			if (collected.equals("c")) {
				luggage.addIt(lj,p1);
				p1.setDefense(p1.getDefense() + defValue);
				p1.PlayerUnchanged(p1);
				p1.setToPositiveValues(p1);
				System.out.println("Your defense has increased by: " + defValue);
				System.out.print(p1);
				map.displayMap();
				map.encounterdItemPos(lj.getLifejkPosx(), lj.getLifejkPosy());//removes item off map
			}
			else if(collected.equals("w") || collected.equals("a") || collected.equals("s") || collected.equals("d")) {
				p1.setToPositiveValues(p1);//make sure values are never negative
				map.movePlayer(collected);//moves player based on answer
				map.displayMap(); 
				p1.PlayerUnchanged(p1);//keeps player's value as it is
			}


		}
		
	}
	public String toString() {
		return ljName + ": \n Defense Value of " +defValue;
	}
}
