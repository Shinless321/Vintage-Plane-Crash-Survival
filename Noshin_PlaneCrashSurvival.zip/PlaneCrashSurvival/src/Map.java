import java.io.Serializable;
import java.util.*;
/**
 * 
 * @author Noshin
 *
 */
public class Map implements Serializable{
	Scanner sc = new Scanner (System.in);

	private Position map [][];     //Creates a map array from position class
	private int xPos;              // x position of player
	private int yPos;             // y position of player
	public int row = 5;           // # of rows in map			
	public int column = 6;		  // # of columns in map	
	private int steps;            // amount of steps taken by player
	
	public int getSteps() {
		return steps;
	}
	/** Constructor that creates map with rows and columns and set the player's position on the map
	 * return O for every tile
	 * 
	 */
	public Map () {
		map = new Position [row][column];                           
		for (int a=0;a<map.length;a++) {
			for (int b=0; b<map[a].length;b++) {
				Position pos1 = new Position ("O");
				map [a][b] = pos1;
			}

		}

		map[yPos][xPos].setPlayerOnTile(true);
	}
/** Method that displays map
 * 
 */
	public void displayMap() {
		for (int a=0;a<map.length;a++) {
			for (int b=0; b<map[a].length;b++) {
				System.out.print(map[a][b] + "  ");
			}
			System.out.println();
		}
	}

	public int getxPos() {
		return xPos;
	}

	public void setxPos(int xPos) {
		this.xPos = xPos;
	}

	public int getyPos() {
		return yPos;
	}

	public void setyPos(int yPos) {
		this.yPos = yPos;
	}
/** Method that places enemy on the map with 
 * give x and y values as long as there is nothing else on that tile
 * 
 * @param x x pos
 * @param y y pos
 */
	public void enemyPos (int x,int y) {
		if ((map[y][x].isEnemyTile()==false) && !(map[y][x].isItemTile()) && (map[y][x].isSafeHouse()==false)) {
			map[y][x].setEnemyTile(true);
		}
	}
/** Method that places item on the map with 
 * give x and y values as long as there is nothing else on that tile
 * 
 * @param x x pos
 * @param y y pos
 */

	public void itemPos (int x, int y) {
		if ((map[y][x].isEnemyTile()==false) && !(map[y][x].isItemTile()) && (map[y][x].isSafeHouse()==false)) {
			map[y][x].setItemTile(true);
		}
	}

/** Once player encounters enemy, object no longer appears on map
 * 
 * @param x x pos
 * @param y y pos
 */
	public void encounterdEnemyPos(int x,int y) {
		map[y][x].setEnemyTile(false);
	}
/** Once player encounters item, object no longer appears on map
	 * 
	 * @param x x pos
	 * @param y y pos
	 */
	public void encounterdItemPos(int x, int y) {
		map[y][x].setItemTile(false);
	}
/** Returns if there are any of the objects for the following three methods on the x,y location of map
 * 
 * @param x x pos
 * @param y y pos
 * @return true or false
 */
	public boolean enemyTileStatus(int x, int y) {
		return map[y][x].isEnemyTile();
	}

	public boolean itemTileStatus(int x, int y) {
		return map[y][x].isItemTile();
	}
	
	public boolean safeHouseStatus(int x, int y) {
		return map[y][x].isSafeHouse();
	}
/** Sets player's position
 * 
 * @param x xpos
 * @param y ypos
 */
	public void playerPos (int x, int y) {
		if (y>-1 && y<map.length && x>-1 &&  x<map[y].length) {
			map[yPos][xPos].setPlayerOnTile(false);
			map[y][x].setPlayerOnTile(true);
			xPos = x;
			yPos = y;

		}
	}
/** Places a safehouse on the map, as long as there is no enemy on it 
 * 
 * @param x
 * @param y
 */
	public void PlaceSafeHouse(int x, int y) {
		if ((map[y][x].isEnemyTile() ==false) ) {
			map[y][x].setSafeHouse(true);
		}
	}



/** Moves the player up, down, left, right on the map location depending on values entered
 * 
 * @param move increases every time player takes a step
 */
	public void movePlayer (String move) {
		if (move.equals("w")){
			playerPos(xPos,yPos - 1);
			map[yPos][xPos].setPlayerOnTile(true);
			steps++;

		}

		else if (move.equals("a")) {
			playerPos(xPos-1, yPos);
			map[yPos][xPos].setPlayerOnTile(true);
			steps++;
		}

		else if (move.equals("s")) {
			playerPos(xPos,yPos +1);
			map[yPos][xPos].setPlayerOnTile(true);
			steps++;
		}

		else if (move.equals("d")) {
			playerPos(xPos +1,yPos);
			map[yPos][xPos].setPlayerOnTile(true);
			steps++;
		}

		else  {
			System.out.println("Key not recognized. Please enter w, a, s or d "
					+ "to move up, left, down or right respectively.");
		}
	}


}
