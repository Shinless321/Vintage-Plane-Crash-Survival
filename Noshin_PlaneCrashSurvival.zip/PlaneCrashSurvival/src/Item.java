
public class Item {


	private int objectSize;
	private int objectPower;
    
	private String objectName;
/** Constructor that initializes object size
 * 
 * @param objn name of object
 * @param obpr power
 */
	public Item (String objn, int obpr) {
		objectSize = 1;
		objectName = objn;
		objectPower = obpr;


	}

	public int getObjectSize() {
		return objectSize;
	}

	public String getObjectName() {
		return objectName;
	}
	public int getObjectPower() {
		return objectPower;
	}

}

