/**Child class shark of enemy
 * 
 * @author Noshin
 *
 */
public class Shark extends Enemy {
	private String sharkName;

	private int sharkX;
	private int sharkY;

	public String getSharkName() {
		return sharkName;
	}

	public int getSharkX() {
		return sharkX;
	}
	public void setSharkX(int sharkX) {
		this.sharkX = sharkX;
	}
	public int getSharkY() {
		return sharkY;
	}
	public void setSharkY(int sharkY) {
		this.sharkY = sharkY;
	}
/**Constructor that intializes shark's name and position on map
 * 
 * @param sharkName name of shark
 * @param x x pos
 * @param y y pos
 * @param map map
 */
	public Shark (String sharkName, int x, int y, Map map) {
		super(sharkName,100,100);
		this.sharkName = sharkName;
		sharkX = x;
		sharkY = y;
		map.enemyPos(x, y);
	}
/**Once player's position and shark's position overlap, player is automatically killed 
 * because their HP is set to zero and the game is over
 * @param p1 player
 * @param shk shark object
 * @param map map
 */
	public void sharkAttack (Player p1, Shark shk, Map map) {
		if(shk.getSharkX() == map.getxPos() && shk.getSharkY() == map.getyPos() && map.enemyTileStatus(shk.getSharkX(),shk.getSharkY()) ==true) {
			map.encounterdEnemyPos(shk.getSharkX(),shk.getSharkY());
			System.out.println("Yikes! YOU HAVE COME ACROSS A " + shk.getSharkName() + "!");
			p1.setHP(0);
			System.out.println(p1);
			System.out.println("You have died. GAME OVER. But thank you for playing Plane Crash Survival.");
			System.exit(0);


		}
	}
}
