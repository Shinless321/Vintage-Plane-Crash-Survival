import java.util.*;
/**Safe house class which is the final destination of the player
 * 
 * @author Noshin
 *
 */
public class SafeHouse {
	int safeHousex;
	int safeHousey;
	public int getSafeHousex() {
		return safeHousex;
	}

	public void setSafeHousex(int safeHousex) {
		this.safeHousex = safeHousex;
	}

	public int getSafeHousey() {
		return safeHousey;
	}

	public void setSafeHousey(int safeHousey) {
		this.safeHousey = safeHousey;
	}



	/**Constructer that creates safe house on map
	 * 
	 * @param x x pos
	 * @param y y pos
	 * @param map map
	 */
	public SafeHouse(int x, int y, Map map) {
		safeHousex = x;
		safeHousey = y;
		map.PlaceSafeHouse(x, y);

	}
	/**When player position and safe house overlap, the user is greeted with a message
	 * player's values are checked to see if they have enough or not
	 * They win if they have reached or surpassed the values
	 * @param p1 player
	 * @param sh safe house object
	 * @param map map
	 */
	public void Safety(Player p1, SafeHouse sh, Map map) {
		Scanner sc = new Scanner(System.in);

		if (map.getxPos() == sh.getSafeHousex() && map.getyPos() == sh.getSafeHousey() &&  map.safeHouseStatus(map.getxPos(),map.getyPos())==true) {
			System.out.println("You have finally made it to the Safe House ALIVE!");
			System.out.println("Let's see if you've made it with sufficient health for the feds to help you recover" +
					" and get you back home... \n Press s.");
			String s = sc.nextLine();

			if(s.equals("s")) {
				System.out.println(p1);
				if (p1.getHP() >=20 && p1.getAttack() >=10 && p1.getDefense() >=10 && p1.getBrainCap()>=10){
					System.out.println("Thank god you're alright!! You're still in optimum shape from the crash! \n "+
							"You have WON Player Crash Survival. Your Score:" +map.getSteps());
					System.exit(0);
				}
				else{ 
					System.out.println("It seems as though you................. oh no you fainted! You could not obtain \n"+

							"a sufficient amount of whatever health and stamina you had left and barely made it alive to the SafeHouse. You lose."
							+"\n Thanks for playing PlaneCrashSurvival!");
					System.exit(0);
				}
			}

		}
	}
}






